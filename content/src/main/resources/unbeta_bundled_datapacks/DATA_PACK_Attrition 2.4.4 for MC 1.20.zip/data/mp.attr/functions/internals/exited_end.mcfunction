#allows this function to be called again when appropriate
advancement revoke @s only mp.attr:exited_end

#references health corrector
execute as @s run function mp.attr:internals/health_corrector