#allows for health loss check
execute as @a[tag=!mp.attr.exclude_player] run scoreboard players set @s mp.attr.known 1

#allows the player to update their preferences
execute as @a run scoreboard players enable @s mp.attr.fixdtext
execute as @a run scoreboard players enable @s mp.attr.flavtext
execute as @a run scoreboard players enable @s mp.attr.sounds

