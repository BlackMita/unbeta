#allows this function to be called again when appropriate
advancement revoke @s only mp.attr:health_gain

#queries the loot table for a random number
execute store result score @s mp.attr.random run loot spawn ~ ~ ~ loot mp.attr:randomizer

#checks for health recoup
execute unless score $mp.attr.fakeplayer mp.attr.recoup matches 0 run function mp.attr:health_gain/hub