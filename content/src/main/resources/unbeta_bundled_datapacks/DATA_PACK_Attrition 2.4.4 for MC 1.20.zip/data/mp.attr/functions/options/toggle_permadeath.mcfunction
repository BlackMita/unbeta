#initiates double toggle prevention
execute if score $mp.attr.fakeplayer mp.attr.perma matches 1 run tag @a add mp.attr.toggling

#turns off permadeath and displays confirmation message
tellraw @a[tag=mp.attr.toggling] {"text":"Permadeath is no longer enabled. Breathe easy!","color":"#D6D6D6","italic":true}
execute as @s[tag=mp.attr.toggling] run scoreboard players set $mp.attr.fakeplayer mp.attr.perma 0

#turns on permadeath and displays confirmation message
tellraw @a[tag=!mp.attr.toggling] {"text":"Permadeath has now been enabled. Exercise caution!","color":"#D6D6D6","italic":true}
execute as @s[tag=!mp.attr.toggling] run scoreboard players set $mp.attr.fakeplayer mp.attr.perma 1

#removes double toggle prevention tag
tag @a[tag=mp.attr.toggling] remove mp.attr.toggling