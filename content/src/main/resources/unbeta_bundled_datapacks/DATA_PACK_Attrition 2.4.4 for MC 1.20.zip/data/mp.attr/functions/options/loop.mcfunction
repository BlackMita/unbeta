#checks for preference updates
execute as @a if score @s mp.attr.fixdtext matches 1.. run function mp.attr:options/toggle_fixed_text
execute as @a if score @s mp.attr.flavtext matches 1.. run function mp.attr:options/toggle_flavor_text
execute as @a if score @s mp.attr.sounds matches 1.. run function mp.attr:options/toggle_event_sounds

#compensates for the defaultgamemode multiplayer mechanic
execute as @a[tag=mp.attr.spirit] run gamemode spectator

#schedules the next check, using the fake player's scores to determine whether or not to continue 
execute if score $mp.attr.fakeplayer mp.attr.perma matches 0.. run schedule function mp.attr:options/loop 20t replace