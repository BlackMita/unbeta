#identifies and game-ends players who have died on 1 heart of max health 
execute if score $mp.attr.fakeplayer mp.attr.perma matches 1 run tag @s add mp.attr.spirit
execute at @s[tag=mp.attr.spirit] run gamemode spectator @s

#I think this is needed because of MC-181604
execute at @s[tag=!mp.attr.spirit] run attribute @s minecraft:generic.max_health base set 2

#tops off player health
effect give @s instant_health 1 6 true

#displays fixed text
execute at @s[tag=mp.attr.spirit] run tellraw @a[tag=!mp.attr.fixed_off] [{"selector":"@s"},{"text":" has surrendered their final heart of maximum health! Their time here has come to a close."}]
execute at @s[tag=!mp.attr.spirit] run tellraw @s[tag=!mp.attr.fixed_off] [{"selector":"@s"},{"text":", you have been shielded from losing your final heart of maximum health."}]

#displays flavor text
execute at @s[tag=mp.attr.spirit,tag=!mp.attr.flavor_off] run tellraw @s [{"text":"Only your soul remains to observe this now-intangible world. . .","color":"#87CEEB","italic":true}]
execute at @s[tag=!mp.attr.spirit,tag=!mp.attr.flavor_off] run tellraw @s [{"text":"The gods take pity on your frail soul. You live to see another day. . .","color":"#87CEEB","italic":true}]

#plays sounds
execute at @s[tag=!mp.attr.sounds_off] run playsound minecraft:ambient.soul_sand_valley.mood neutral @s ~ ~ ~ 10