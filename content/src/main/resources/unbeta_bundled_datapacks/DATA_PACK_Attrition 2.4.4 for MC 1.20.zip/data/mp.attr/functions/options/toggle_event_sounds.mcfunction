#initiates double toggle prevention
tag @s[tag=mp.attr.sounds_off] add mp.attr.toggling

#turns on sounds and displays confirmation message
tellraw @s[tag=mp.attr.toggling] {"text":"Event sounds for Attrition have been toggled on!","color":"#D6D6D6","italic":true}
tag @s[tag=mp.attr.toggling] remove mp.attr.sounds_off

#turns off sounds and displays confirmation message
tellraw @s[tag=!mp.attr.toggling] {"text":"Event sounds for Attrition have been toggled off!","color":"#D6D6D6","italic":true}
tag @s[tag=!mp.attr.toggling] add mp.attr.sounds_off

#removes double toggle prevention tag
tag @s[tag=mp.attr.toggling] remove mp.attr.toggling

#allows option to be triggered again
scoreboard players enable @s mp.attr.sounds
scoreboard players set @s mp.attr.sounds 0