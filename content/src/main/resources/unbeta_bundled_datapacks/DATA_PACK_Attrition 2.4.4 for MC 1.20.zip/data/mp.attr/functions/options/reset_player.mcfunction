#returns player to normal survival conditions
gamemode survival @s
scoreboard players set @s mp.attr.score 20
attribute @s minecraft:generic.max_health base set 20
effect clear @s
effect give @s minecraft:instant_health 1 6 true
tag @s remove mp.attr.spirit

#displays confirmation message
execute as @s run tellraw @s {"text":"Your base health has been reset to its normal value!","color":"#D6D6D6","italic":true}