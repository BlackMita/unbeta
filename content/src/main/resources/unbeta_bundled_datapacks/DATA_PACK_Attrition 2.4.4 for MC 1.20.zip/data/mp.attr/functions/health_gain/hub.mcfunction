#blocks health gain when needed
execute if score @s mp.attr.score >= $mp.attr.fakeplayer mp.attr.cap run function mp.attr:health_gain/overflow

#triggers normal health gain
execute if score @s mp.attr.score < $mp.attr.fakeplayer mp.attr.cap run function mp.attr:health_gain/execute