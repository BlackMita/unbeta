#sets up initial values of mp.attr.score
execute as @s store result score @s mp.attr.score run attribute @s minecraft:generic.max_health get

#delays setting mp.attr.known to 1 to avoid having the player lose health immediately upon world load
schedule function mp.attr:internals/recognition 20t replace