#initiates double toggle prevention
execute if score $mp.attr.fakeplayer mp.attr.recoup matches 1 run tag @a add mp.attr.toggling

#turns off health recoup and displays confirmation message
tellraw @a[tag=mp.attr.toggling] {"text":"Consuming an enchanted golden apple will no longer restore a heart of maximum health.","color":"#D6D6D6","italic":true}
execute as @s[tag=mp.attr.toggling] run scoreboard players set $mp.attr.fakeplayer mp.attr.recoup 0

#turns on health recoup and displays confirmation message
tellraw @a[tag=!mp.attr.toggling] {"text":"Consuming an enchanted golden apple will now restore a heart of maximum health!","color":"#D6D6D6","italic":true}
execute as @s[tag=!mp.attr.toggling] run scoreboard players set $mp.attr.fakeplayer mp.attr.recoup 1

#removes double toggle prevention tag
tag @a[tag=mp.attr.toggling] remove mp.attr.toggling