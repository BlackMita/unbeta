#triggers game end if on final heart of health
execute if score @s mp.attr.score matches 2 run function mp.attr:health_loss/perish

#triggers normal health loss
execute if score @s mp.attr.score matches 4.. run function mp.attr:health_loss/execute
execute if score @s mp.attr.score matches 2.. run function mp.attr:health_loss/visual_update