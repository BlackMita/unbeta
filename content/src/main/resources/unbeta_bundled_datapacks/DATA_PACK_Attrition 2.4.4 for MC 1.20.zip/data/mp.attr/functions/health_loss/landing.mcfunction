#allows this function to be called again when appropriate
advancement revoke @s only mp.attr:health_loss

#queries the loot table for a random number
execute store result score @s mp.attr.random run loot spawn ~ ~ ~ loot mp.attr:randomizer

#continues 
execute as @s run function mp.attr:health_loss/hub