#displays randomly chosen flavor text
execute if score @s[scores={mp.attr.random=1}] mp.attr.score matches 4..10 run tellraw @s [{"text":"An apple a day keeps the impending specter of assured demise at bay.","color":"#3F5A36","italic":true}]
execute if score @s[scores={mp.attr.random=2}] mp.attr.score matches 4..10 run tellraw @s [{"text":"It’s at times like these that we appreciate the fruits of our hard work the most.","color":"#3F5A36","italic":true}]
execute if score @s[scores={mp.attr.random=3}] mp.attr.score matches 4..10 run tellraw @s [{"text":"Crisis averted! - for the time being, at least. . .","color":"#3F5A36","italic":true}]
execute if score @s[scores={mp.attr.random=4}] mp.attr.score matches 4..10 run tellraw @s [{"text":"You have been granted an extra life - go celebrate by jumping into a skeleton mosh pit!","color":"#3F5A36","italic":true}]
execute if score @s[scores={mp.attr.random=5}] mp.attr.score matches 4..10 run tellraw @s [{"text":"As the gods smile upon your courageous exploits, you feel revitalized.","color":"#3F5A36","italic":true}]

execute if score @s[scores={mp.attr.random=1}] mp.attr.score matches 12..24 run tellraw @s [{"text":"Eve lost everything by eating a luscious, glowing pome such as that one, but for the same folly your health is renewed?","color":"#30A02D","italic":true}]
execute if score @s[scores={mp.attr.random=2}] mp.attr.score matches 12..24 run tellraw @s [{"text":"If you’ll forgive the cliché, that last bite was truly the apple of your health bar’s eye. . .","color":"#30A02D","italic":true}]
execute if score @s[scores={mp.attr.random=3}] mp.attr.score matches 12..24 run tellraw @s [{"text":"Upon further review of your most recent repast, the gods have decided to kick your health up a Notch.","color":"#30A02D","italic":true}]
execute if score @s[scores={mp.attr.random=4}] mp.attr.score matches 12..24 run tellraw @s [{"text":"According to nutritionists, what you just ate is universally recognized as an exceedingly balanced breakfast.","color":"#30A02D","italic":true}]
execute if score @s[scores={mp.attr.random=5}] mp.attr.score matches 12..24 run tellraw @s [{"text":"As the gods smile upon your courageous exploits, you feel revitalized.","color":"#30A02D","italic":true}]

execute if score @s[scores={mp.attr.random=1}] mp.attr.score matches 26.. run tellraw @s [{"text":"For similar results, you could’ve just turned that one into a Mojang banner pattern.","color":"#22E524","italic":true}]
execute if score @s[scores={mp.attr.random=2}] mp.attr.score matches 26.. run tellraw @s [{"text":"Achievement unlocked: Absorption Heart Addict","color":"#22E524","italic":true}]
execute if score @s[scores={mp.attr.random=3}] mp.attr.score matches 26.. run tellraw @s [{"text":"The gods think you’re being a bit of a show-off by this point; however, a deal is a deal.","color":"#22E524","italic":true}]
execute if score @s[scores={mp.attr.random=4}] mp.attr.score matches 26.. run tellraw @s [{"text":"They say fortune favors the bold, but this is starting to get out of hand.","color":"#22E524","italic":true}]
execute if score @s[scores={mp.attr.random=5}] mp.attr.score matches 26.. run tellraw @s [{"text":"As the gods smile upon your courageous exploits, you feel revitalized.","color":"#22E524","italic":true}]

#Dislays special flavor text for consuming a Potion of Accretion (Contrition data pack)
execute if score @s[scores={mp.attr.random=6}] mp.attr.score matches 4..10 run tellraw @s [{"text":"The finest of wines are worthless to you, where a nectar like this more health can imbue.","color":"#3F5A36","italic":true}]
execute if score @s[scores={mp.attr.random=7}] mp.attr.score matches 4..10 run tellraw @s [{"text":"It tastes of raspberries and death. How curious.","color":"#3F5A36","italic":true}]
execute if score @s[scores={mp.attr.random=8}] mp.attr.score matches 4..10 run tellraw @s [{"text":"The gods are hoping you have more where that came from!","color":"#3F5A36","italic":true}]

execute if score @s[scores={mp.attr.random=6}] mp.attr.score matches 12..24 run tellraw @s [{"text":"The bottle's label says 'Made From Concentrate', so as an informed consumer, you. . . guzzled it down anyway. Right.","color":"#30A02D","italic":true}]
execute if score @s[scores={mp.attr.random=7}] mp.attr.score matches 12..24 run tellraw @s [{"text":"The viscous liquid, flowing throughout your being, revivifies you with its steadfast presence.","color":"#30A02D","italic":true}]
execute if score @s[scores={mp.attr.random=8}] mp.attr.score matches 12..24 run tellraw @s [{"text":"'Warning: May contain trace amounts of glowstone dust'","color":"#30A02D","italic":true}]

execute if score @s[scores={mp.attr.random=6}] mp.attr.score matches 26.. run tellraw @s [{"text":"Have you considered trying some water for a change?","color":"#22E524","italic":true}]
execute if score @s[scores={mp.attr.random=7}] mp.attr.score matches 26.. run tellraw @s [{"text":"Your thirst is quenched, your mind is at ease; what more can one desire in this world?","color":"#22E524","italic":true}]
execute if score @s[scores={mp.attr.random=8}] mp.attr.score matches 26.. run tellraw @s [{"text":"Achievement Unlocked: Fruit Punch Connoisseur","color":"#22E524","italic":true}]

#Dislays special flavor text for getting a Lifesteal kill (Contrition data pack)
execute if score @s[scores={mp.attr.random=9}] mp.attr.score matches 4..10 run tellraw @s [{"text":"As the gods smile upon your courageous exploits, you feel revitalized.","color":"#3F5A36","italic":true}]
execute if score @s[scores={mp.attr.random=10}] mp.attr.score matches 4..10 run tellraw @s [{"text":"The gods see in you a soul blackened by cunning and deceit; but you got the kill, and so the heart is yours.","color":"#3F5A36","italic":true}]
execute if score @s[scores={mp.attr.random=11}] mp.attr.score matches 4..10 run tellraw @s [{"text":"Violence is always the answer when you're this low on maximum health!","color":"#3F5A36","italic":true}]
execute if score @s[scores={mp.attr.random=12}] mp.attr.score matches 4..10 run tellraw @s [{"text":"Now's no time for restraint - go back for seconds, you need it!","color":"#3F5A36","italic":true}]

execute if score @s[scores={mp.attr.random=9}] mp.attr.score matches 12..24 run tellraw @s [{"text":"As the gods smile upon your courageous exploits, you feel revitalized.","color":"#30A02D","italic":true}]
execute if score @s[scores={mp.attr.random=10}] mp.attr.score matches 12..24 run tellraw @s [{"text":"An indescribable surge of life force courses through your body.","color":"#30A02D","italic":true}]
execute if score @s[scores={mp.attr.random=11}] mp.attr.score matches 12..24 run tellraw @s [{"text":"Your psyche hears an unmistakeable crinkling noise, as if the gods are collectively reaching for their microwaveable popcorn.","color":"#30A02D","italic":true}]
execute if score @s[scores={mp.attr.random=12}] mp.attr.score matches 12..24 run tellraw @s [{"text":"As they say, all's fair in love and life stealing!","color":"#30A02D","italic":true}]

execute if score @s[scores={mp.attr.random=9}] mp.attr.score matches 26.. run tellraw @s [{"text":"As the gods smile upon your courageous exploits, you feel revitalized.","color":"#22E524","italic":true}]
execute if score @s[scores={mp.attr.random=10}] mp.attr.score matches 26.. run tellraw @s [{"text":"There's honorable and valorous combat, and then there's. . . whatever the hell that was","color":"#22E524","italic":true}]
execute if score @s[scores={mp.attr.random=11}] mp.attr.score matches 26.. run tellraw @s [{"text":"You've captured the attention of the blood god, who rewards your conquest.","color":"#22E524","italic":true}]
execute if score @s[scores={mp.attr.random=12}] mp.attr.score matches 26.. run tellraw @s [{"text":"Achievement Unlocked: Unlicensed Hematologist","color":"#22E524","italic":true}]