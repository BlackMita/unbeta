#adds the scoreboards that are the foundation for the data pack
scoreboard objectives add mp.attr.score dummy "Health score"
scoreboard objectives add mp.attr.death minecraft.custom:minecraft.time_since_death "Time since last death"
scoreboard objectives add mp.attr.random dummy "Randomizer"
scoreboard objectives add mp.attr.known dummy "Recognized"

#adds the scoreboards that are used for preferences and game modes
scoreboard objectives add mp.attr.fixdtext trigger "Fixed text"
scoreboard objectives add mp.attr.flavtext trigger "Flavor text"
scoreboard objectives add mp.attr.sounds trigger "Event sounds"

scoreboard objectives add mp.attr.recoup dummy "Health recoup"
scoreboard objectives add mp.attr.cap dummy "Health upgrade"
scoreboard objectives add mp.attr.perma dummy "Permadeath"

#sets up initial settings for the data pack's fake player
execute unless score $mp.attr.fakeplayer mp.attr.score matches 1 run scoreboard players set $mp.attr.fakeplayer mp.attr.recoup 1
execute unless score $mp.attr.fakeplayer mp.attr.score matches 1 run scoreboard players set $mp.attr.fakeplayer mp.attr.perma 1
execute unless score $mp.attr.fakeplayer mp.attr.score matches 1 run scoreboard players set $mp.attr.fakeplayer mp.attr.cap 30

#prevents the game from auto-reverting to default settings 
scoreboard players set $mp.attr.fakeplayer mp.attr.score 1

#passively toggles testing conditions off
execute if score $mp.attr.fakeplayer mp.attr.known matches 1 run schedule function mp.attr:options/testing_off 20t replace

#starts the schedule loop that checks for preference updates
schedule function mp.attr:options/loop 20t replace