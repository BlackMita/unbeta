#sets adjusted base health based on previous mp.attr.score, in descending order
execute if score @s mp.attr.score matches 38 run attribute @s minecraft:generic.max_health base set 40
execute if score @s mp.attr.score matches 36 run attribute @s minecraft:generic.max_health base set 38
execute if score @s mp.attr.score matches 34 run attribute @s minecraft:generic.max_health base set 36
execute if score @s mp.attr.score matches 32 run attribute @s minecraft:generic.max_health base set 34
execute if score @s mp.attr.score matches 30 run attribute @s minecraft:generic.max_health base set 32
execute if score @s mp.attr.score matches 28 run attribute @s minecraft:generic.max_health base set 30
execute if score @s mp.attr.score matches 26 run attribute @s minecraft:generic.max_health base set 28
execute if score @s mp.attr.score matches 24 run attribute @s minecraft:generic.max_health base set 26
execute if score @s mp.attr.score matches 22 run attribute @s minecraft:generic.max_health base set 24
execute if score @s mp.attr.score matches 20 run attribute @s minecraft:generic.max_health base set 22
execute if score @s mp.attr.score matches 18 run attribute @s minecraft:generic.max_health base set 20
execute if score @s mp.attr.score matches 16 run attribute @s minecraft:generic.max_health base set 18
execute if score @s mp.attr.score matches 14 run attribute @s minecraft:generic.max_health base set 16
execute if score @s mp.attr.score matches 12 run attribute @s minecraft:generic.max_health base set 14
execute if score @s mp.attr.score matches 10 run attribute @s minecraft:generic.max_health base set 12
execute if score @s mp.attr.score matches 8 run attribute @s minecraft:generic.max_health base set 10
execute if score @s mp.attr.score matches 6 run attribute @s minecraft:generic.max_health base set 8
execute if score @s mp.attr.score matches 4 run attribute @s minecraft:generic.max_health base set 6
execute if score @s mp.attr.score matches 2 run attribute @s minecraft:generic.max_health base set 4

#re-calibrates mp.attr.score
execute store result score @s mp.attr.score run attribute @s minecraft:generic.max_health base get

#displays fixed text
execute unless score @s mp.attr.score = $mp.attr.fakeplayer mp.attr.cap run tellraw @a[tag=!mp.attr.fixed_off] [{"selector":"@s"},{"text":" has gained a heart of maximum health!"}]
execute if score @s mp.attr.score = $mp.attr.fakeplayer mp.attr.cap run tellraw @a[tag=!mp.attr.fixed_off] [{"selector":"@s"},{"text":" has gained their final heart of maximum health!"}]

#initiates flavor text display
execute at @s[tag=!mp.attr.flavor_off] run function mp.attr:health_gain/flavor_text

#plays sounds for gaining health
execute at @s[tag=!mp.attr.sounds_off] run playsound minecraft:block.chorus_flower.grow neutral @s ~ ~ ~ 10