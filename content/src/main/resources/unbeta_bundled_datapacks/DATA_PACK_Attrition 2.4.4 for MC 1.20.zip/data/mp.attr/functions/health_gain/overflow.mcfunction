#displays fixed text
execute as @s run tellraw @s[tag=!mp.attr.fixed_off] [{"selector":"@s"},{"text":", you cannot increase your maximum health any further!"}]

#displays flavor text
execute as @s[tag=!mp.attr.flavor_off] run tellraw @s [{"text":"The gods cannot allow any one being to become stronger than this.","color":"#87CEEB","italic":true}]

#plays sounds for not gaining health
execute at @s[tag=!mp.attr.sounds_off] run playsound minecraft:block.chorus_flower.death neutral @s ~ ~ ~ 10