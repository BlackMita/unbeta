#initiates double toggle prevention
tag @s[tag=mp.attr.flavor_off] add mp.attr.toggling

#turns on flavor text and displays confirmation message
tellraw @s[tag=mp.attr.toggling] {"text":"Flavor text for Attrition has been toggled on!","color":"#D6D6D6","italic":true}
tag @s[tag=mp.attr.toggling] remove mp.attr.flavor_off

#turns off flavor text and displays confirmation message
tellraw @s[tag=!mp.attr.toggling] {"text":"Flavor text for Attrition has been toggled off!","color":"#D6D6D6","italic":true}
tag @s[tag=!mp.attr.toggling] add mp.attr.flavor_off

#removes double toggle prevention tag
tag @s[tag=mp.attr.toggling] remove mp.attr.toggling

#allows option to be triggered again
scoreboard players enable @s mp.attr.flavtext
scoreboard players set @s mp.attr.flavtext 0