#turns off testing conditions
gamerule keepInventory false
gamerule doImmediateRespawn false

#resets passive toggle
scoreboard players set $mp.attr.fakeplayer mp.attr.known 0
