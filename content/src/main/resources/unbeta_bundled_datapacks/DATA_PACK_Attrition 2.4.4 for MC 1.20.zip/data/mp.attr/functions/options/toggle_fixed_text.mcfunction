#initiates double toggle prevention
tag @s[tag=mp.attr.fixed_off] add mp.attr.toggling

#turns on flavor text and displays confirmation message
tellraw @s[tag=mp.attr.toggling] {"text":"Fixed text for Attrition has been toggled on!","color":"#D6D6D6","italic":true}
tag @s[tag=mp.attr.toggling] remove mp.attr.fixed_off

#turns off flavor text and displays confirmation message
tellraw @s[tag=!mp.attr.toggling] {"text":"Fixed text for Attrition has been toggled off!","color":"#D6D6D6","italic":true}
tag @s[tag=!mp.attr.toggling] add mp.attr.fixed_off

#removes double toggle prevention tag
tag @s[tag=mp.attr.toggling] remove mp.attr.toggling

#allows option to be triggered again
scoreboard players enable @s mp.attr.fixdtext
scoreboard players set @s mp.attr.fixdtext 0