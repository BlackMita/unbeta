#initiates double toggle prevention
execute if score $mp.attr.fakeplayer mp.attr.cap matches 20 run tag @a add mp.attr.toggling

#turns off health cap and displays confirmation message
tellraw @a[tag=mp.attr.toggling] {"text":"You can now accumulate up to fifteen hearts of maximum health.","color":"#D6D6D6","italic":true}
execute as @s[tag=mp.attr.toggling] run scoreboard players set $mp.attr.fakeplayer mp.attr.cap 30

#turns on health cap and displays confirmation message
tellraw @a[tag=!mp.attr.toggling] {"text":"You can no longer accumulate more than ten hearts of maximum health.","color":"#D6D6D6","italic":true}
execute as @s[tag=!mp.attr.toggling] run scoreboard players set $mp.attr.fakeplayer mp.attr.cap 20

#removes double toggle prevention tag
tag @a[tag=mp.attr.toggling] remove mp.attr.toggling