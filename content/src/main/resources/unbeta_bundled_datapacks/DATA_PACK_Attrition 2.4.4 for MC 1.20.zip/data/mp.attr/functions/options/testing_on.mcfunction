#initiates testing conditions
gamerule keepInventory true
gamerule doImmediateRespawn true

give @s minecraft:enchanted_golden_apple 32

#prepares passive toggle
scoreboard players set $mp.attr.fakeplayer mp.attr.known 1

#displays confirmation message
execute as @s run tellraw @s [{"text":"You may now freely test Attrition using the ","color":"#D6D6D6","italic":true},{"text":"/kill ","color":"#555555","italic":false},{"text":"command and your enchanted golden apples. To exit testing conditions, quit and rejoin this world.","color":"#D6D6D6","italic":true}]
