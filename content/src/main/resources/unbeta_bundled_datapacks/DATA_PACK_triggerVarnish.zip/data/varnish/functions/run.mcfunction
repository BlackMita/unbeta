execute as @e[type=immersive_paintings:glow_painting] run data merge entity @s {Invulnerable:1b}
execute as @e[type=immersive_paintings:glow_graffiti] run data merge entity @s {Invulnerable:1b}

tellraw @s {"text":"The varnish sets, preserving the artwork.","color":"yellow"}
