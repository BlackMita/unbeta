scoreboard players enable @a varnish
execute as @a[scores={varnish=1..}] run function varnish:run
scoreboard players set @a[scores={varnish=1..}] varnish 0
