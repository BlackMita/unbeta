scoreboard objectives add varnish trigger
scoreboard players enable @a varnish
tellraw @a [{"text":"[Varnish] ","color":"gold"},{"text":"Type /trigger varnish to apply varnish.","color":"yellow"}]
